#!/usr/bin/env python3
"""Install a third, playable Terminalkaos stage after Snowyard+Cowboy V4 patches."""
from pathlib import Path
import sys
path=Path(sys.argv[1] if len(sys.argv)>1 else 'game.gd')
s=path.read_text('utf-8')
def replace(old,new):
 global s
 n=s.count(old)
 if n!=1:raise RuntimeError('Terminalkaos: expected 1 occurrence, got %s for %r'%(n,old[:120]))
 s=s.replace(old,new,1)
def before(anchor,insert):
 replace(anchor,insert+'\n'+anchor)

# use transparent full-body poses with a consistent foot anchor
poses=['idle','walk1','walk2','run1','run2','run3','crouch','block','hurt1','hurt2','punch1','punch2','kick1','pickup','throw_windup','throw','win']
preload='const BG_KAOS:Texture2D=preload("res://assets/terminalkaos_stage.png")\nconst WORKER = {\n'+',\n'.join(' "%s":preload("res://assets/worker_%s.png")'%(p,p) for p in poses)+'\n}\n'
before('const SNOWBALL_FRAMES = [',preload)
replace('var stage_id:int = 0    # 0=Terminal, 1=Snögården','var stage_id:int = 0    # 0=Terminal, 1=Snögården, 2=Terminalkaos')
before('var touches:Dictionary = {}', '''var worker_mode:String="idle"
var worker_mode_time:float=0.0
var worker_walk_anim:float=0.0
var worker_speed:float=0.0
var worker_throw_cd:float=2.1
var worker_cage_cd:float=8.5
var worker_punch_cd:float=1.0
var worker_packages:Array=[]
var worker_cages:Array=[]
var puddle_glide:float=0.0
var worker_defense_flash:float=0.0
var worker_defense_label:String=""
var worker_packet_count:int=0
var worker_block_count:int=0''')
replace('const SELECT_BACK:Rect2 = Rect2(343,420,274,52)', '''const SELECT_KAOS:Rect2=Rect2(290,389,380,62)
const SELECT_BACK:Rect2 = Rect2(343,463,274,52)''')
replace('   elif SELECT_BACK.has_point(at):','   elif SELECT_KAOS.has_point(at):\n    choose_stage(2)\n   elif SELECT_BACK.has_point(at):')
replace('  elif state == "stage_select" and event.keycode == KEY_2:\n   choose_stage(1)', '''  elif state == "stage_select" and event.keycode == KEY_2:
   choose_stage(1)
  elif state == "stage_select" and event.keycode == KEY_3:
   choose_stage(2)''')
# choose_stage handles 0,1,2, and all existing round/menu mechanics remain
replace(' snowballs.clear()\n flashes.clear()', ''' snowballs.clear()
 worker_packages.clear()
 worker_cages.clear()
 worker_mode="idle"
 worker_mode_time=0.0
 worker_speed=0.0
 worker_walk_anim=0.0
 worker_throw_cd=2.1
 worker_cage_cd=8.5
 worker_punch_cd=1.0
 puddle_glide=0.0
 worker_defense_flash=0.0
 worker_defense_label=""
 worker_packet_count=0
 worker_block_count=0
 flashes.clear()''')
# do not alter damage for existing stages; add stage-specific special enemy attacks
before('func _process(delta:float) -> void:', '''func worker_throw_package() -> void:
 if stage_id!=2 or enemy_hurt>0.0:return
 var side:float=signf(p.x-e.x)
 if side==0.0:side=-1.0
 var start:Vector2=e+Vector2(side*62,-125)
 worker_packages.append({"p":start,"v":Vector2(side*260,-68),"life":3.4,"rot":0.0})
 sparks(start,Color("#eec58a"),5)

func worker_launch_cage() -> void:
 if stage_id!=2 or enemy_hurt>0.0:return
 var side:float=signf(p.x-e.x)
 if side==0.0:side=-1.0
 worker_cages.append({"p":e+Vector2(side*83,-50),"vx":side*155.0,"life":3.8})
 sparks(e+Vector2(side*80,-65),Color("#fff0b9"),12)

func worker_receive_projectile(where:Vector2,amount:float,label:String) -> void:
 if down("block"):
  worker_block_count+=1
  worker_defense_label="BLOCKERAD!"
  worker_defense_flash=0.52
  sparks(where,Color("#8be7fc"),13)
 elif (down("crouch") and label=="paket" and p.y>=FLOOR-3.0) or (p.y<FLOOR-66.0 and label=="bur"):
  worker_defense_label="UNDVIKEN!"
  worker_defense_flash=0.46
  sparks(where,Color("#b3efff"),7)
 else:
  hp=maxf(0.0,hp-amount)
  player_hurt=0.28
  shake=0.16
  sparks(where,Color("#ffc382"),15)

func update_terminalkaos(delta:float) -> void:
 if stage_id!=2:return
 worker_defense_flash=maxf(0.0,worker_defense_flash-delta)
 worker_throw_cd=maxf(0.0,worker_throw_cd-delta)
 worker_cage_cd=maxf(0.0,worker_cage_cd-delta)
 worker_punch_cd=maxf(0.0,worker_punch_cd-delta)
 var gap:float=absf(p.x-e.x)
 var toward:float=signf(p.x-e.x)
 if toward==0.0:toward=-1.0
 if enemy_hurt>0.0:
  worker_mode="hurt"
  worker_mode_time=0.0
  worker_speed=0.0
 elif worker_mode in ["pickup","throw_windup","throw","recover","cage_windup","cage_release","punch","kick"]:
  worker_mode_time=maxf(0.0,worker_mode_time-delta)
  if worker_mode_time<=0.0:
   match worker_mode:
    "punch","kick":
     worker_mode="idle"
    "pickup":
     worker_mode="throw_windup";worker_mode_time=0.38
    "throw_windup":
     worker_throw_package();worker_mode="throw";worker_mode_time=0.33
    "throw":
     worker_mode="recover";worker_mode_time=0.45
    "cage_windup":
     worker_launch_cage();worker_mode="cage_release";worker_mode_time=0.42
    "cage_release":
     worker_mode="recover";worker_mode_time=0.52
    _:
     worker_mode="idle"
 else:
  if worker_cage_cd<=0.0 and gap>135.0:
   worker_mode="cage_windup";worker_mode_time=0.7;worker_cage_cd=randf_range(8.0,10.0)
  elif worker_throw_cd<=0.0 and gap>155.0:
   worker_mode="pickup";worker_mode_time=0.43;worker_throw_cd=randf_range(2.5,3.8)
  else:
   var target_speed:float=0.0
   if gap>250.0:target_speed=toward*66.0
   elif gap<125.0:target_speed=-toward*48.0
   worker_speed=move_toward(worker_speed,target_speed,delta*135.0)
   e.x=clampf(e.x+worker_speed*delta,45.0,915.0)
   worker_walk_anim+=delta
   worker_mode="walk" if absf(worker_speed)>5.0 else "idle"
 # Physical projectiles are updated independently of animation states.
 for packet in worker_packages.duplicate():
  packet["p"]+=packet["v"]*delta
  var vel:Vector2=packet["v"]
  vel.y+=150.0*delta
  packet["v"]=vel
  packet["rot"]+=delta*5.0
  packet["life"]-=delta
  if absf(packet["p"].x-p.x)<37.0 and absf(packet["p"].y-(p.y-104.0))<66.0:
   worker_receive_projectile(packet["p"],8.0,"paket")
   worker_packet_count+=1
   worker_packages.erase(packet)
  elif packet["life"]<=0.0 or packet["p"].y>FLOOR+15.0 or packet["p"].x<0.0 or packet["p"].x>WIDTH:
   worker_packages.erase(packet)
 for cart in worker_cages.duplicate():
  cart["p"].x+=cart["vx"]*delta
  cart["life"]-=delta
  if absf(cart["p"].x-p.x)<54.0 and p.y>FLOOR-65.0:
   worker_receive_projectile(cart["p"],13.0,"bur")
   worker_cages.erase(cart)
  elif cart["life"]<=0.0 or cart["p"].x<-100.0 or cart["p"].x>WIDTH+100.0:
   worker_cages.erase(cart)
''')
# Existing V4 AI stage 1 / else stage 0 - prevent stage2 double movement
replace(' if stage_id==1:\n  update_cowboy_ai(delta)', ''' if stage_id==2:
  update_terminalkaos(delta)
 elif stage_id==1:
  update_cowboy_ai(delta)''')
# Stage 2 player can slide across puddles (wet zones), but maintain input control
replace(' p.x = clampf(p.x+move_dir*237.0*delta,48.0,912.0)', ''' if stage_id==2 and p.y>=FLOOR-2.0 and ((p.x>390.0 and p.x<515.0) or (p.x>700.0 and p.x<825.0)):
  puddle_glide=move_toward(puddle_glide,move_dir*310.0,delta*380.0)
  p.x=clampf(p.x+puddle_glide*delta,48.0,912.0)
 else:
  puddle_glide=move_toward(puddle_glide,0.0,delta*440.0)
  p.x=clampf(p.x+move_dir*237.0*delta,48.0,912.0)''')
# No accidental unwanted melee for stage2 when a package is being prepared
replace(' if enemy_cooldown<=0 and enemy_hurt<=0 and distance<118 and absf(p.y-e.y)<95:', ''' if stage_id==2 and enemy_hurt<=0.0 and distance<115.0 and worker_punch_cd<=0.0 and worker_mode not in ["pickup","throw_windup","throw","cage_windup","cage_release"]:
  worker_mode="punch" if randf()<0.75 else "kick"
  worker_mode_time=0.32
  worker_punch_cd=randf_range(1.8,2.5)
 if enemy_cooldown<=0 and enemy_hurt<=0 and distance<118 and absf(p.y-e.y)<95 and stage_id!=2:''')
# Enemy touch damage from player punches is original 'strike' and works for all stages.
replace('message="COWBOY VINNER!" if stage_id==1 else "KUNDEN VINNER!"','message="COWBOY VINNER!" if stage_id==1 else "TERMINALARBETAREN VINNER!" if stage_id==2 else "KUNDEN VINNER!"')
# Sprite selection: separate genuine 640x620 full body pictures
before('func draw_fighter(at:Vector2,courier:bool) -> void:', '''func worker_art() -> Texture2D:
 if enemy_hurt>0.0:
  return WORKER["hurt1"] if int(clock*9.0)%2==0 else WORKER["hurt2"]
 if state=="match_end" and enemy_score>player_score:return WORKER["win"]
 match worker_mode:
  "walk":return WORKER["walk1"] if int(worker_walk_anim*5.4)%2==0 else WORKER["walk2"]
  "pickup":return WORKER["pickup"]
  "throw_windup":return WORKER["throw_windup"]
  "throw":return WORKER["throw"]
  "recover":return WORKER["idle"]
  "cage_windup":return WORKER["punch1"]
  "cage_release":return WORKER["punch2"]
  "punch":return WORKER["punch1"]
  "kick":return WORKER["kick1"]
  "block":return WORKER["block"]
  "crouch":return WORKER["crouch"]
  "hurt":return WORKER["hurt1"]
  _:return WORKER["idle"]
''')
replace('func draw_fighter(at:Vector2,courier:bool) -> void:', '''func draw_fighter(at:Vector2,courier:bool) -> void:
 if stage_id==2 and not courier:
  var face:float=1.0 if p.x>e.x else -1.0
  draw_set_transform(at,0.0,Vector2(face,1.0))
  var scale:float=0.48
  draw_texture_rect(worker_art(),Rect2(-640.0*scale/2.0,-570.0*scale,640.0*scale,620.0*scale),false)
  draw_set_transform(Vector2.ZERO)
  return''')
# Fix wrong idle sprite from unhelpful source crop? patched by package creator.
replace('txt("WOODY" if stage_id==1 else "KUNDEN",','txt("TERMINALARBETAREN" if stage_id==2 else "WOODY" if stage_id==1 else "KUNDEN",')
# Smaller label to avoid HUD edge, at x730
replace('Vector2(851 if stage_id==1 else 844,25),22,','Vector2(739 if stage_id==2 else 851 if stage_id==1 else 844,25),19 if stage_id==2 else 22,')
# Menu third option and extra headroom
replace('centered("TVÅ BANOR  ·  TVÅ MOTSTÅNDARE",213,17,', 'centered("TRE BANOR  ·  TRE MOTSTÅNDARE",213,17,')
replace('menu_button("2  ·  SNÖGÅRDEN",SELECT_SNOW,true)', '''menu_button("2  ·  SNÖGÅRDEN",SELECT_SNOW,true)
 menu_button("3  ·  TERMINALKAOS",SELECT_KAOS,true)''')
# Improve stage selection spacing for third choice
replace('const SELECT_TERMINAL:Rect2 = Rect2(290,243,380,70)','const SELECT_TERMINAL:Rect2 = Rect2(290,221,380,60)')
replace('const SELECT_SNOW:Rect2 = Rect2(290,329,380,70)','const SELECT_SNOW:Rect2 = Rect2(290,303,380,60)')
replace('centered("VÄLJ DIN NÄSTA STRID",201,19,','centered("VÄLJ DIN NÄSTA STRID",191,19,')
replace('var backdrop:Texture2D=BG_TERMINAL if stage_id==0 else BG_SNOW','var backdrop:Texture2D=BG_TERMINAL if stage_id==0 else BG_SNOW if stage_id==1 else BG_KAOS')
# V4 in gameplay still has original selection line
replace('draw_texture_rect(BG_TERMINAL if stage_id==0 else BG_SNOW,Rect2(0,0,960,540),false)', 'draw_texture_rect(BG_TERMINAL if stage_id==0 else BG_SNOW if stage_id==1 else BG_KAOS,Rect2(0,0,960,540),false)')
# New enemy projectiles and rain; HUD/controls are drawn atop these.
before('func _draw() -> void:', '''func terminalkaos_rain() -> void:
 # Long diagonal lines repeat deterministically, no per-frame random flicker.
 for i in range(48):
  var x:float=fposmod(float(i*173+31)+clock*(82.0+float(i%4)*9.0),960.0)
  var y:float=fposmod(float(i*113+49)+clock*(235.0+float(i%7)*8.0),540.0)
  draw_line(Vector2(x,y),Vector2(x-4.0,y+17.0),Color("#d3e8f8",0.16),1.0)
 # Subtle slick spots where the player has a longer glide.
 for center_x in [452.0,760.0]:
  draw_ellipse_puddle(Vector2(center_x,FLOOR+12.0))

func draw_ellipse_puddle(at:Vector2) -> void:
 for i in range(3):
  var width:float=47.0+float(i)*17.0
  draw_arc(at,width,PI*0.04,PI*0.96,20,Color("#74c4ed",0.24),2.0)

func terminalkaos_objects() -> void:
 for packet in worker_packages:
  var at:Vector2=packet["p"]
  draw_set_transform(at,packet["rot"])
  draw_rect(Rect2(-13,-11,26,22),Color("#c3915f"))
  draw_rect(Rect2(-13,-11,26,22),Color("#573b28"),false,2.0)
  draw_rect(Rect2(-3,-11,6,22),Color("#f4dfb8"))
  draw_set_transform(Vector2.ZERO)
 for cart in worker_cages:
  var at:Vector2=cart["p"]
  var r:Rect2=Rect2(at.x-40.0,at.y-71.0,80.0,82.0)
  draw_rect(r,Color("#bad2dc",0.13))
  for i in range(1,5):
   draw_line(Vector2(r.position.x+float(i)*r.size.x/5.0,r.position.y),Vector2(r.position.x+float(i)*r.size.x/5.0,r.end.y),Color("#d2e0e8"),2.2)
  for i in range(1,4):
   draw_line(Vector2(r.position.x,r.position.y+float(i)*r.size.y/4.0),Vector2(r.end.x,r.position.y+float(i)*r.size.y/4.0),Color("#d2e0e8"),2.0)
  draw_rect(r,Color("#d7ebf1"),false,3.0)
  draw_circle(r.position+Vector2(12,r.size.y+5),6.0,Color("#1d2832"))
  draw_circle(r.position+Vector2(70,r.size.y+5),6.0,Color("#1d2832"))
 if worker_defense_flash>0.0:
  txt(worker_defense_label,Vector2(p.x-57.0,p.y-183.0),18,Color("#a8efff"))
''')
replace('if stage_id==1: snow_effects()', '''if stage_id==1: snow_effects()
 if stage_id==2: terminalkaos_rain()''')
replace('for ball in snowballs: draw_snowball(ball)', '''for ball in snowballs: draw_snowball(ball)
 if stage_id==2:terminalkaos_objects()''')
replace(' txt("HOPPA ÖVER LÅGA · SKYDD STOPPAR ALLA",Vector2(149,413),17,Color("#8fdefb"))', ''' txt("HOPPA ÖVER LÅGA · SKYDD STOPPAR ALLA",Vector2(149,413),17,Color("#8fdefb"))
 txt("TERMINALKAOS: HUKA UNDER PAKET, SKYDDA MOT BURAR",Vector2(149,439),15,Color("#f4d9a2"))''')
path.write_text(s,'utf-8')
print('TERMINALKAOS V1 INSTALLED, chars:',len(s))
