# PAKETKRIGET – Terminalkaos (bana 3)

- Nytt lastkajsområde, inspirerat av användarens foto, med blå PostNord-trailrar, regn och våta asfaltsytor.
- Ny motståndare: Terminalarbetaren. Flera individuella transparenta fullkroppssprites, till exempel gång, löpning, hukning, block, slag, spark, paketplockning, kast, skada och seger.
- Nya anfall: kastade kartonger och rullande paketbur. Huka under kartongerna; skydda mot båda attackerna. Hoppa över paketburar.
- Halkiga zoner med förlängd glidrörelse, regn, animationer och särskilda träffeffekter.
- De ursprungliga Terminalen och Snögården bevaras, liksom Cowboy V4.

## Installation i befintligt GitHub-projekt
Lägg hela detta arkiv (`terminalkaos.zip`, utan att packa upp) i roten på `Manngez/Terminal-Clash` och committa. Den förberedda Android-workflowen packar upp det i bygget, applicerar `install_terminalkaos.py` efter Snowyard + V4 och kör `terminalkaos_smoke_test.gd`. Den färdiga APK:n finns som `TerminalClash-Android-APK` under Actions.
