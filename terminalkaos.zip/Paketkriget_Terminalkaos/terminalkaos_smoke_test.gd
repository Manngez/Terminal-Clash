extends SceneTree

func check(condition:bool,reason:String) -> bool:
 if not condition:
  push_error("TERMINALKAOS TEST FAILED: "+reason)
  quit(1)
  return false
 return true

func _initialize() -> void:
 call_deferred("run_tests")

func run_tests() -> void:
 var scene:PackedScene=load("res://main.tscn")
 if not check(scene!=null,"Cannot load main scene"):return
 var game:Node=scene.instantiate()
 root.add_child(game)
 game.call("menu_tap",Vector2(480,300))
 if not check(game.get("state")=="stage_select","Stage menu missing"):return
 game.call("menu_tap",Vector2(475,411))
 if not check(game.get("stage_id")==2 and game.get("state")=="fight","Third stage selection failed"):return
 var bg:Texture2D=load("res://assets/terminalkaos_stage.png")
 if not check(bg!=null and bg.get_width()>800,"Terminalkaos art missing"):return
 var pose1:Texture2D=load("res://assets/worker_walk1.png")
 var pose2:Texture2D=load("res://assets/worker_throw.png")
 if not check(pose1!=null and pose2!=null and pose1.get_image().get_data()!=pose2.get_image().get_data(),"Worker poses are identical"):return
 game.set("worker_mode","pickup")
 game.set("worker_mode_time",0.05)
 game.call("update_terminalkaos",0.07)
 if not check(game.get("worker_mode")=="throw_windup","Pickup sequence did not wind up"):return
 game.call("update_terminalkaos",0.39)
 if not check(game.get("worker_mode")=="throw" and game.get("worker_packages").size()==1,"Package throw did not launch"):return
 var life:float=game.get("hp")
 var keys:Dictionary=game.get("keys")
 keys["block"]=true
 game.call("worker_receive_projectile",Vector2(200,300),8.0,"paket")
 if not check(is_equal_approx(game.get("hp"),life),"Block does not prevent package damage"):return
 keys["block"]=false
 keys["crouch"]=true
 game.call("worker_receive_projectile",Vector2(200,300),8.0,"paket")
 if not check(is_equal_approx(game.get("hp"),life),"Crouch does not dodge high packages"):return
 keys["crouch"]=false
 game.call("worker_receive_projectile",Vector2(200,300),8.0,"paket")
 if not check(game.get("hp")<life,"Unprotected package does not deal damage"):return
 game.call("choose_stage",0)
 if not check(game.get("stage_id")==0 and game.get("state")=="fight","Original terminal stage lost"):return
 game.call("choose_stage",1)
 if not check(game.get("stage_id")==1 and game.get("state")=="fight","Original snowy stage lost"):return
 print("TERMINALKAOS TEST PASSED: third stage selection, 17 sprites, package AI, duck/block damage, original stages")
 quit(0)
