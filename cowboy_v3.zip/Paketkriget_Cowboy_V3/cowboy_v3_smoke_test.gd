extends SceneTree

func _initialize() -> void:
 call_deferred("_test")

func check(condition:bool, reason:String) -> bool:
 if not condition:
  push_error("COWBOY V3 TEST FAILED: " + reason)
  quit(1)
  return false
 return true

func _test() -> void:
 var scene:PackedScene=load("res://main.tscn")
 if not check(scene!=null,"Cannot load main game"):return
 var game:Node=scene.instantiate()
 root.add_child(game)
 game.call("choose_stage",1)
 if not check(game.get("stage_id")==1,"Snowyard not selectable"):return
 game.set("p",Vector2(250,426))
 game.set("e",Vector2(710,426))
 if not check(is_equal_approx(game.call("cowboy_v3_sprite_scale"),-1.0),"Cowboy must face LEFT when standing to courier's right"):return
 game.set("p",Vector2(850,426))
 if not check(is_equal_approx(game.call("cowboy_v3_sprite_scale"),1.0),"Cowboy must face RIGHT when courier passes him"):return
 game.set("p",Vector2(250,426))
 game.set("clock",0.04)
 var frame_a:Texture2D=game.call("cowboy_animated_texture")
 game.set("clock",0.39)
 var frame_b:Texture2D=game.call("cowboy_animated_texture")
 if not check(frame_a!=frame_b,"Idle uses one repeated still image"):return
 game.set("cowboy_mode","walk")
 game.set("cowboy_rush_time",0.0)
 if not check(game.call("cowboy_animation_group")=="walk","Walking state not connected"):return
 game.set("clock",0.1)
 frame_a=game.call("cowboy_animated_texture")
 game.set("clock",0.3)
 frame_b=game.call("cowboy_animated_texture")
 if not check(frame_a!=frame_b,"Walk animation fails to advance frames"):return
 game.set("cowboy_rush_time",0.9)
 if not check(game.call("cowboy_animation_group")=="run","Fast movement has no run animation"):return
 game.set("cowboy_mode","throw_windup")
 game.set("cowboy_mode_time",0.49)
 if not check(game.call("cowboy_animation_group")=="windup","Windup not animated"):return
 frame_a=game.call("cowboy_animated_texture")
 game.set("cowboy_mode_time",0.06)
 frame_b=game.call("cowboy_animated_texture")
 if not check(frame_a!=frame_b,"Windup uses static image"):return
 game.set("cowboy_mode","throw_release")
 game.set("cowboy_mode_time",0.22)
 game.set("cowboy_throw_low",false)
 if not check(game.call("cowboy_animation_group")=="release","Normal throw animation not selected"):return
 game.set("cowboy_throw_low",true)
 if not check(game.call("cowboy_animation_group")=="throw_low","Low throw missing unique animation"):return
 game.set("cowboy_mode","throw_recover")
 if not check(game.call("cowboy_animation_group")=="recover","Throw recovery missing"):return
 game.set("cowboy_mode","block")
 if not check(game.call("cowboy_animation_group")=="block","Cowboy block has no pose"):return
 game.set("cowboy_mode","getup")
 if not check(game.call("cowboy_animation_group")=="getup","Get-up animation not connected"):return
 game.set("enemy_hurt",0.19)
 if not check(game.call("cowboy_animation_group")=="hurt","Damage animation missing"):return
 game.set("enemy_hurt",0.0)
 game.set("state","match_end")
 game.set("ehp",0.0)
 game.set("player_score",2)
 game.set("enemy_score",0)
 if not check(game.call("cowboy_animation_group")=="ko","KO does not use falling animation"):return
 game.set("ehp",100.0)
 game.set("player_score",0)
 game.set("enemy_score",2)
 if not check(game.call("cowboy_animation_group")=="win","Victory animation missing"):return
 print("COWBOY V3 TEST PASSED: facing, multiple idle/walk frames, run, throw windup/release/low/recovery, block, hurt, KO, win")
 quit(0)
