#!/usr/bin/env python3
"""Install real multi-frame animated cowboy textures in the Snowyard game.

Run AFTER scripts/fix_cowboy_snowballs.py and AFTER the V3 asset ZIP was
unpacked under assets/. Fails hard when source drift occurs.
"""
from pathlib import Path
from PIL import Image
import json, sys

path=Path(sys.argv[1] if len(sys.argv)>1 else 'game.gd')
manifest=json.loads(Path('assets/cowboy_v3_manifest.json').read_text('utf-8'))
series=manifest['frames']
required=['idle','walk','run','windup','release','recover','throw_low','crouch','jump','block','punch','kick','hurt','ko','getup','win']
for key in required:
    assert key in series and len(series[key])>=2, f'Missing animated sprite sequence: {key}'
    for name in series[key]:
        p=Path('assets')/name
        assert p.is_file(),f'No sprite {p}'
        with Image.open(p) as im:
            assert im.size==(640,620) and im.mode=='RGBA',f'Unexpected sprite dimensions/alpha {p}'
assert sum(map(len,series.values()))>=70

s=path.read_text('utf-8')
start='const SNOWBALL_FRAMES = ['
assert s.count(start)==1, 'Could not find original snowball texture list'

def preload_for(name):
    return 'preload("res://assets/%s")'%name

lines=['const COWBOY_V3 = {']
for key in required:
    line=' "%s": [%s]'%(key,', '.join(preload_for(name) for name in series[key]))
    if key!=required[-1]:line+=','
    lines.append(line)
lines.append('}')
s=s.replace(start,'\n'.join(lines)+'\n\n'+start,1)

fstart='func fighter_art(courier:bool) -> Texture2D:\n'
fend='func draw_fighter(at:Vector2,courier:bool) -> void:\n'
assert s.count(fstart)==1 and s.count(fend)==1, 'Missing patched fighter renderer'
a=s.index(fstart)
b=s.index(fend,a)
new='''func cowboy_animation_group() -> String:
 # Show KO/win even after combat simulation stops updating.
 if state=="round_end" or state=="match_end":
  if ehp<=0.0 or (player_score>enemy_score):return "ko"
  return "win"
 if enemy_hurt>0.0:return "hurt"
 if enemy_attack_time>0.0:
  return "kick" if enemy_kick_time>0.0 else "punch"
 if e.y<FLOOR-5.0:return "jump"
 match cowboy_mode:
  "throw_windup":return "windup"
  "throw_release":return "throw_low" if cowboy_throw_low else "release"
  "throw_recover":return "recover"
  "walk":return "run" if cowboy_rush_time>0.0 else "walk"
  "punch":return "punch"
  "kick":return "kick"
  "dodge":return "crouch" if e.y>=FLOOR-5.0 else "jump"
  "block":return "block"
  "getup":return "getup"
 return "idle"

func cowboy_animation_index(group:String) -> int:
 var frames:Array=COWBOY_V3[group]
 var count:int=frames.size()
 if count<=1:return 0
 if group=="windup":
  return clampi(int(clampf((0.50-cowboy_mode_time)/0.50,0.0,0.999)*count),0,count-1)
 if group=="release" or group=="throw_low":
  return clampi(int(clampf((0.26-cowboy_mode_time)/0.26,0.0,0.999)*count),0,count-1)
 if group=="recover":
  return clampi(int(clampf((0.36-cowboy_mode_time)/0.36,0.0,0.999)*count),0,count-1)
 if group=="getup":
  return clampi(int(clampf((0.32-cowboy_mode_time)/0.32,0.0,0.999)*count),0,count-1)
 if group=="hurt":
  return clampi(int(clampf((0.26-enemy_hurt)/0.26,0.0,0.999)*count),0,count-1)
 if group=="punch":
  return clampi(int(clampf((0.32-enemy_attack_time)/0.32,0.0,0.999)*count),0,count-1)
 if group=="kick":
  return clampi(int(clampf((0.27-enemy_kick_time)/0.27,0.0,0.999)*count),0,count-1)
 if group=="ko":
  return count-1
 var fps:float=4.0
 match group:
  "walk":fps=10.0
  "run":fps=16.0
  "jump":fps=8.0
  "crouch":fps=5.0
  "block":fps=4.0
  "win":fps=3.0
  "getup":fps=6.0
 return int(clock*fps) % count

func cowboy_animated_texture() -> Texture2D:
 var group:String=cowboy_animation_group()
 var textures:Array=COWBOY_V3[group]
 return textures[cowboy_animation_index(group)]

func fighter_art(courier:bool) -> Texture2D:
 if not courier and stage_id==1:
  return cowboy_animated_texture()
 var library:Dictionary=COURIER if courier else CUSTOMER
 var hurt:float=player_hurt if courier else enemy_hurt
 var attack:float=attack_time if courier else enemy_attack_time
 var kick:bool=player_kick_time>0.0 if courier else enemy_kick_time>0.0
 if hurt>0.0:return library["hurt"]
 if state=="match_end" and ((courier and player_score>enemy_score) or (not courier and enemy_score>player_score)):
  return library["win"]
 if attack>0.0:return library["kick" if kick else "punch1"]
 if courier and crouch_active and state=="fight":return library["crouch"]
 if (p.y if courier else e.y)<FLOOR-5.0:return library["jump"]
 if courier and (down("left") or down("right")) and state=="fight":
  return library["walk1"] if int(clock*10.0)%2==0 else library["walk2"]
 if not courier and absf(p.x-e.x)>125.0 and state=="fight":
  return library["walk1"] if int(clock*9.0)%2==0 else library["walk2"]
 return library["idle"]

'''
s=s[:a]+new+s[b:]

# The new character art naturally faces RIGHT (the original V2 cowboy faced
# LEFT). Invert ONLY the visible draw transform. Keep old logic/test helper
# untouched for backward-compatibility with existing gameplay regression test.
old='else cowboy_sprite_x_scale()'
assert s.count(old)==1, 'Could not find cowboy draw orientation'
s=s.replace(old,'else cowboy_v3_sprite_scale()',1)

needle='func cowboy_animation_group() -> String:\n'
assert s.count(needle)==1
s=s.replace(needle,'func cowboy_v3_sprite_scale() -> float:\n return -cowboy_sprite_x_scale()\n\n'+needle,1)

# Separate low and high snowball releases in the actual animation selection.
old='var cowboy_mode:String = "idle"'
assert s.count(old)==1
s=s.replace(old,old+'\nvar cowboy_throw_low:bool = false',1)
old=' cowboy_mode = "idle"\n cowboy_mode_time = 0.0\n cowboy_velocity = 0.0'
assert s.count(old)==1
s=s.replace(old,' cowboy_throw_low = false\n'+old,1)
old=' var kind:String="high" if style<0.46 else "mid" if style<0.80 else "low"'
assert s.count(old)==1
s=s.replace(old,old+'\n cowboy_throw_low = kind=="low"',1)

# Animate the three rising poses instead of snapping from hurt to idle.
old=' if cowboy_mode=="hurt":\n  cowboy_mode="idle"'
assert s.count(old)==1, 'Could not locate recovery transition'
s=s.replace(old,''' if cowboy_mode=="hurt":
  cowboy_mode="getup"
  cowboy_mode_time=0.32
  return
 if cowboy_mode=="getup":
  cowboy_mode_time=maxf(0.0,cowboy_mode_time-delta)
  if cowboy_mode_time<=0.0:cowboy_mode="idle"
  return''',1)

# Add an actual defensive cowboy stance when a close strike approaches.
old=' if cowboy_mode=="dodge":\n  cowboy_mode_time=maxf(0.0,cowboy_mode_time-delta)'
assert s.count(old)==1
s=s.replace(old,''' if cowboy_mode=="block":
  cowboy_mode_time=maxf(0.0,cowboy_mode_time-delta)
  if cowboy_mode_time<=0.0:cowboy_mode="idle"
  return
 if cowboy_mode=="dodge":
  cowboy_mode_time=maxf(0.0,cowboy_mode_time-delta)''',1)
old=' if cowboy_rush_time>0.0:\n  cowboy_rush_time=maxf(0.0,cowboy_rush_time-delta)'
assert s.count(old)==1
s=s.replace(old,''' if distance<135.0 and attack_time>0.06 and cowboy_dodge_cooldown<=0.0 and randf()<0.22:
  cowboy_mode="block"
  cowboy_mode_time=0.32
  cowboy_dodge_cooldown=2.3
  return
'''+old,1)

# A defending enemy takes reduced melee damage; the pose means something.
old='  ehp = maxf(0.0,ehp-damage)'
assert s.count(old)==1
s=s.replace(old,'  ehp = maxf(0.0,ehp-(damage*0.22 if stage_id==1 and cowboy_mode=="block" else damage))',1)

path.write_text(s,'utf-8')
print('COWBOY V3 INSTALLED: %d individual sprite frames, %d animation sets'%(sum(map(len,series.values())),len(required)))
