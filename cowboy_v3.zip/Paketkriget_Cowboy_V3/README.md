# Paketkriget – Cowboy V3: riktiga animationer

Denna version innehåller **77 transparenta PNG-rutor i 16 separata animationsserier** för cowboyen. Figuren är tecknad med hatten och hela kroppen i varje ruta. Samtliga bilder har 640×620 transparent bildyta och samma fotankare (y=570).

## Så använder du den

Detta är ett **tilläggspaket till Snöduellen**, inte en färdig APK. Ladda upp ZIP-filen `cowboy_v3.zip` till roten av GitHub-projektet `Manngez/Terminal-Clash` utan att packa upp. Projektets Android-bygge installerar bildfilerna och kopplar animationerna automatiskt via `scripts/use_cowboy_v3.py`.

## Animationer

Idle (7), gång (8), löpning (8), kastförberedelse (5), kast (2), återhämtning (4), lågkast (5), hukning (5), hopp (4), blockering (3), slag (6), spark (6), skada (5), KO (4), uppresning (3), seger (2).

**Observera:** Vissa rutor är manuellt utvalda ur AI-genererad pixelkonst och det kan återstå visuell finjustering. Sprite-sheetens källbilder har medvetet delats med sin ursprungliga transparens i stället för att färgsegmenteras så att stövlar och byxor inte raderas.

Spelet behåller tidigare korrigerad snöbollsträff, hukning och blockering. Det finns ett extra Godot-smoketest för att kontrollera att *olika* textramar används i körning, gång, kast och skada.
