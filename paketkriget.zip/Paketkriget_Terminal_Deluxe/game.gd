extends Node2D
const FLOOR := 426.0
const BG = preload("res://assets/terminal.png")
const C = {
 "idle":preload("res://assets/courier_idle.png"),
 "walk1":preload("res://assets/courier_walk1.png"),
 "walk2":preload("res://assets/courier_walk2.png"),
 "punch1":preload("res://assets/courier_punch1.png"),
 "kick":preload("res://assets/courier_kick.png"),
 "jump":preload("res://assets/courier_jump.png"),
 "hurt":preload("res://assets/courier_hurt.png"),
 "win":preload("res://assets/courier_win.png")
}
const E = {
 "idle":preload("res://assets/customer_idle.png"),
 "walk1":preload("res://assets/customer_walk1.png"),
 "walk2":preload("res://assets/customer_walk2.png"),
 "punch1":preload("res://assets/customer_punch1.png"),
 "kick":preload("res://assets/customer_kick.png"),
 "jump":preload("res://assets/customer_jump.png"),
 "hurt":preload("res://assets/customer_hurt.png"),
 "win":preload("res://assets/customer_win.png")
}
var p := Vector2(260,FLOOR)
var e := Vector2(700,FLOOR)
var vy := 0.0
var evy := 0.0
var hp := 100.0
var ehp := 100.0
var clock := 0.0
var timer := 99.0
var cooldown := 0.0
var enemy_cooldown := 0.0
var attack_time := 0.0
var enemy_attack_time := 0.0
var player_kick_time := 0.0
var enemy_kick_time := 0.0
var player_hurt := 0.0
var enemy_hurt := 0.0
var freeze := 0.0
var special := 0.0
var shake := 0.0
var round_num := 1
var player_score := 0
var enemy_score := 0
var state := "title"
var message := ""
var particles := []
var projectiles := []
var touches := {}
var keys := {}
var buttons := {
 "left":Rect2(16,452,68,68),"right":Rect2(90,452,68,68),"jump":Rect2(164,452,68,68),
 "punch":Rect2(633,452,68,68),"kick":Rect2(707,452,68,68),
 "block":Rect2(781,452,68,68),"special":Rect2(855,452,88,68)
}
func _ready() -> void:
 texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
func _input(event:InputEvent) -> void:
 if event is InputEventScreenTouch:
  if event.pressed:
   if state != "fight":
    next_round()
   else:
    var b = button_at(event.position)
    touches[event.index] = b
    keys[b] = true
  elif touches.has(event.index):
   var old = touches[event.index]
   touches.erase(event.index)
   keys[old] = touches.values().has(old)
 elif event is InputEventScreenDrag and touches.has(event.index):
  var old = touches[event.index]
  var new = button_at(event.position)
  touches[event.index] = new
  keys[old] = touches.values().has(old)
  keys[new] = true
 elif event is InputEventKey and event.pressed and state != "fight":
  next_round()
func button_at(at:Vector2) -> String:
 for key in buttons:
  if buttons[key].has_point(at):return key
 return ""
func down(key:String) -> bool:
 var kb = {"left":KEY_A,"right":KEY_D,"jump":KEY_W,"punch":KEY_J,"kick":KEY_K,"block":KEY_L,"special":KEY_I}
 return keys.get(key,false) or Input.is_key_pressed(kb[key])
func next_round() -> void:
 if state=="title" or state=="match_end":
  player_score=0
  enemy_score=0
  round_num=1
 p=Vector2(260,FLOOR)
 e=Vector2(700,FLOOR)
 vy=0
 evy=0
 hp=100
 ehp=100
 timer=99
 cooldown=0
 enemy_cooldown=0
 attack_time=0
 enemy_attack_time=0
 player_kick_time=0
 enemy_kick_time=0
 player_hurt=0
 enemy_hurt=0
 special=0
 projectiles.clear()
 particles.clear()
 state="fight"
func sparks(at:Vector2,tint:Color) -> void:
 for i in range(16):
  var angle=TAU*float(i)/16.0
  particles.append({"p":at,"v":Vector2(cos(angle),sin(angle))*randf_range(90,290),"life":0.38,"c":tint})
func strike(dmg:float,reach:float,lasting:float,kick:bool=false) -> void:
 cooldown=lasting
 attack_time=lasting*0.65
 player_kick_time=attack_time if kick else 0.0
 if absf(p.x-e.x)<reach and absf(p.y-e.y)<85:
  ehp-=dmg
  enemy_hurt=0.28
  e.x=clampf(e.x+signf(e.x-p.x)*(38 if kick else 22),60,900)
  freeze=0.085 if kick else 0.05
  shake=0.16
  special=minf(100,special+14)
  sparks(e+Vector2(0,-110),Color("#ffd86e"))
func _process(delta:float) -> void:
 clock+=delta
 if state!="fight":
  queue_redraw()
  return
 if freeze>0:
  freeze=maxf(0,freeze-delta)
  queue_redraw()
  return
 timer-=delta
 cooldown=maxf(0,cooldown-delta)
 enemy_cooldown=maxf(0,enemy_cooldown-delta)
 attack_time=maxf(0,attack_time-delta)
 player_kick_time=maxf(0,player_kick_time-delta)
 enemy_kick_time=maxf(0,enemy_kick_time-delta)
 enemy_attack_time=maxf(0,enemy_attack_time-delta)
 player_hurt=maxf(0,player_hurt-delta)
 enemy_hurt=maxf(0,enemy_hurt-delta)
 shake=maxf(0,shake-delta)
 for spark in particles:
  spark["life"]-=delta
  spark["p"]+=spark["v"]*delta
 particles=particles.filter(func(a):return a["life"]>0)
 var move_dir=float(int(down("right"))-int(down("left")))
 if player_hurt>0:move_dir=0
 p.x=clampf(p.x+move_dir*225*delta,50,910)
 if down("jump") and p.y>=FLOOR and player_hurt<=0:vy=-485
 vy+=1200*delta
 p.y=minf(FLOOR,p.y+vy*delta)
 if p.y>=FLOOR:vy=0
 var distance=absf(p.x-e.x)
 if enemy_hurt<=0:
  var enemy_dir=signf(p.x-e.x) if distance>125 else -signf(p.x-e.x) if distance<68 else 0.0
  e.x=clampf(e.x+enemy_dir*112*delta,50,910)
 evy+=1200*delta
 e.y=minf(FLOOR,e.y+evy*delta)
 if e.y>=FLOOR:evy=0
 if cooldown<=0 and player_hurt<=0 and not down("block"):
  if down("punch"):strike(9,112,0.34)
  elif down("kick"):strike(15,146,0.58,true)
  elif down("special") and special>=40:
   special-=40
   projectiles.append({"p":p+Vector2(0,-106),"dir":signf(e.x-p.x)})
   cooldown=0.6
 if enemy_cooldown<=0 and enemy_hurt<=0 and distance<115 and absf(p.y-e.y)<90:
  enemy_cooldown=randf_range(0.8,1.4)
  enemy_attack_time=0.34
  enemy_kick_time=0.29 if distance>90 else 0.0
  if not down("block"):
   hp-=10
   player_hurt=0.25
   p.x=clampf(p.x+signf(p.x-e.x)*25,50,910)
   freeze=0.05
   shake=0.15
   sparks(p+Vector2(0,-110),Color("#ff8070"))
 for projectile in projectiles.duplicate():
  projectile["p"]+=Vector2(projectile["dir"]*510*delta,0)
  if absf(projectile["p"].x-e.x)<45:
   ehp-=21
   enemy_hurt=0.28
   sparks(e+Vector2(0,-105),Color("#6bdfff"))
   projectiles.erase(projectile)
  elif projectile["p"].x<0 or projectile["p"].x>960:
   projectiles.erase(projectile)
 if hp<=0 or ehp<=0 or timer<=0:
  if hp>ehp:
   player_score+=1
   message="POSTNORD VINNER!"
  elif ehp>hp:
   enemy_score+=1
   message="KUNDEN VINNER!"
  else:message="OAVGJORT!"
  round_num+=1
  state="match_end" if max(player_score,enemy_score)>=2 else "round_end"
 queue_redraw()
func txt(value:String,pos:Vector2,size:int=22,color:Color=Color.WHITE) -> void:
 draw_string(ThemeDB.fallback_font,pos,value,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)
func draw_fighter(at:Vector2,courier:bool) -> void:
 var library=C if courier else E
 var hurt=player_hurt if courier else enemy_hurt
 var atk=attack_time if courier else enemy_attack_time
 var is_kick=player_kick_time>0 if courier else enemy_kick_time>0
 var moving=(down("left") or down("right")) if courier else absf(p.x-e.x)>125
 var key="idle"
 if hurt>0:
  key="hurt"
 elif state!="fight" and ((courier and player_score>enemy_score) or (not courier and enemy_score>player_score)):
  key="win"
 elif atk>0:
  key="kick" if is_kick else "punch1"
 elif at.y<FLOOR-5:
  key="jump"
 elif moving:
  key="walk1" if int(clock*9)%2==0 else "walk2"
 var art:Texture2D=library[key]
 # Source PNG frames are genuinely transparent and contain all legs/boots.
 # Shared frame size and foot anchor avoid pose-to-pose jitter and levitation.
 var scale_factor=0.48
 var width=640.0*scale_factor
 var height=620.0*scale_factor
 var facing=e.x>p.x if courier else p.x>e.x
 draw_set_transform(at,0,Vector2(1 if facing else -1,1))
 draw_texture_rect(art,Rect2(-width/2,-570.0*scale_factor,width,height),false)
 draw_set_transform(Vector2.ZERO)
 if courier and down("block") and state=="fight":
  var shield_dir=1 if facing else -1
  draw_arc(at+Vector2(40*shield_dir,-126),40,-1.15,1.15,18,Color("#9be5ff",0.8),4)
func _draw() -> void:
 draw_texture_rect(BG,Rect2(0,0,960,540),false)
 draw_rect(Rect2(0,0,960,103),Color("#0b1021",0.97))
 draw_rect(Rect2(0,100,960,4),Color("#e5b654"))
 draw_rect(Rect2(18,33,365,24),Color("#692638"))
 draw_rect(Rect2(18,33,365*maxf(0,hp)/100,24),Color("#f0c451"))
 draw_rect(Rect2(577,33,365,24),Color("#692638"))
 draw_rect(Rect2(577+365*(1-maxf(0,ehp)/100),33,365*maxf(0,ehp)/100,24),Color("#f0c451"))
 txt("POSTNORD",Vector2(18,25),22,Color("#65d8ff"))
 txt("KUNDEN",Vector2(844,25),22,Color("#ff9a8d"))
 txt(str(ceili(timer)),Vector2(459,58),38,Color("#ffe0a0"))
 txt("RONDER %d : %d" % [player_score,enemy_score],Vector2(409,85),17)
 draw_rect(Rect2(18,74,190,11),Color("#26324e"))
 draw_rect(Rect2(18,74,190*special/100,11),Color("#48c9e9"))
 for at in [p,e]:
  draw_ellipse_shadow(at)
 if shake>0:draw_set_transform(Vector2(randf_range(-3,3),randf_range(-3,3)))
 draw_fighter(p,true)
 draw_fighter(e,false)
 draw_set_transform(Vector2.ZERO)
 for spark in particles:
  draw_circle(spark["p"],5*spark["life"]/0.38,spark["c"])
 for projectile in projectiles:
  draw_rect(Rect2(projectile["p"].x-16,projectile["p"].y-13,32,26),Color("#c9985e"))
  draw_rect(Rect2(projectile["p"].x-3,projectile["p"].y-13,6,26),Color("#7e5b39"))
 for name in buttons:
  var r:Rect2=buttons[name]
  draw_rect(r,Color("#28435e",0.88) if not down(name) else Color("#3d8caa",0.95))
  draw_rect(r,Color("#a9d8ed"),false,2)
  txt({"left":"<","right":">","jump":"HOPP","punch":"SLAG","kick":"SPARK","block":"SKYDD","special":"SUPER"}[name],r.position+Vector2(8,39),15)
 if state!="fight":
  draw_rect(Rect2(185,149,590,215),Color("#081426",0.95))
  draw_rect(Rect2(185,149,590,215),Color("#e5b654"),false,3)
  if state=="title":
   txt("PAKETKRIGET",Vector2(297,234),45,Color("#ffd36a"))
   txt("TRYCK FOR ATT STARTA",Vector2(343,296),23)
  else:
   txt(message,Vector2(287,234),34,Color("#ffd36a"))
   txt("TRYCK FOR ATT FORTSATTA",Vector2(324,296),23)
func draw_ellipse_shadow(at:Vector2) -> void:
 var pts=PackedVector2Array()
 for i in range(32):
  var angle=TAU*float(i)/32.0
  pts.append(Vector2(at.x+55*cos(angle),FLOOR+6+9*sin(angle)))
 draw_colored_polygon(pts,Color("#071019",0.36))
