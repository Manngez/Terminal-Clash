extends SceneTree

func _initialize() -> void:
 call_deferred("test_snowyard")

func assert_game(condition:bool,reason:String) -> bool:
 if not condition:
  push_error("SNOWYARD TEST FAILED: " + reason)
  quit(1)
  return false
 return true

func test_snowyard() -> void:
 var scene:PackedScene=load("res://main.tscn")
 if not assert_game(scene!=null,"Main scene missing"):return
 var game:Node=scene.instantiate()
 root.add_child(game)
 if not assert_game(game.get("state")=="title","Title state missing"):return
 game.call("menu_tap",Vector2(480,300))
 if not assert_game(game.get("state")=="stage_select","Stage select button not working"):return
 game.call("menu_tap",Vector2(470,358))
 if not assert_game(game.get("stage_id")==1 and game.get("state")=="fight","Snowyard stage not selected"):return
 if not assert_game(game.get("buttons").has("crouch"),"Crouch button missing"):return
 var pressed:Dictionary=game.get("keys")
 pressed["crouch"]=true
 game.call("_process",0.016)
 if not assert_game(game.get("crouch_active"),"Player crouch not enabled"):return
 pressed["crouch"]=false
 game.call("_process",0.016)
 if not assert_game(not game.get("crouch_active"),"Player remains crouched after release"):return
 game.call("enemy_snow_throw")
 if not assert_game(game.get("snowballs").size()>0,"Cowboy cannot throw snowball"):return
 var touch:InputEventScreenTouch=InputEventScreenTouch.new()
 touch.position=Vector2(480,121)
 touch.pressed=true
 game.call("_input",touch)
 if not assert_game(game.get("state")=="pause","Pause button failed"):return
 game.call("menu_tap",Vector2(480,240))
 if not assert_game(game.get("state")=="fight","Resume failed"):return
 game.call("clear_controls")
 game.call("choose_stage",0)
 if not assert_game(game.get("stage_id")==0 and game.get("state")=="fight","Terminal stage broken"):return
 print("SNOWYARD TEST PASSED: main menu, level select, both stages, crouch, snowball AI and pause")
 quit(0)
