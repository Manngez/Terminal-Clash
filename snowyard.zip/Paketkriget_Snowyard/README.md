# PAKETKRIGET — SNÖDUELLEN

Spelbar Godot 4.3-projektmapp (960 x 540, liggande mobilskärm).

**Bana 1: Terminalen** — den befintliga banan med kundmotståndaren, stridsanimationerna och pixelbakgrunden kvar.

**Bana 2: Snögården** — fyra blå PostNord-bilar framför ett snötäckt upplag i Västerbotten. En cowboy med gulrutig skjorta, väst och hatt håller sig på avstånd och kastar snöbollar. Han kan också slåss när du kommer nära.

Startmeny: STARTA SPEL -> välj TERMINALEN eller SNÖGÅRDEN. SÅ SPELAR DU visar kontrollerna. PAUS när som helst under match.

Kontroller på skärm: vänster/höger, HOPP, HUKA, SLAG, SPARK, SKYDD, SUPER.
Tangentbord: A/D rörelse, W hopp, S huka, J slag, K spark, L block, I super, P/Esc paus.

På snöbanan: höga och mellanhöga snöbollar går att huka under. Hoppa över låga snöbollar; blockera om du inte hinner. Sparkar och slag kan avvärja inkommande snöbollar i rätt ögonblick. Slag och sparkar skadar cowboyen på nära håll.

Godot-skriptet och transparenta sprite-bilder finns separat i mappen. Inga fiender eller kontroller är fastmålade i snöbakgrunden.

## Bygga Android-APK via GitHub
Ladda upp hela ZIP-filen `snowyard.zip` som EN fil i roten av GitHub-repot `Manngez/Terminal-Clash`. Godot-konfigurationen för Android export bibehålls från det repo som fungerat tidigare. GitHub Actions byter till filerna i ZIP-paketet och bygger APK automatiskt.

Spelet är testat visuellt med en separat sammanställning av bakgrund och figurer. Endast en faktisk Godot-runtime- och mobiltest kan verifiera animationer/kollisioner i själva motorn.
