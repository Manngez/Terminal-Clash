extends Node2D

# PAKETKRIGET — Terminal Clash + Snowyard Showdown
# Godot 4.3, 960x540 landscape. All characters are full-body RGBA textures.
const FLOOR:float = 426.0
const WIDTH:float = 960.0
const BG_TERMINAL:Texture2D = preload("res://assets/terminal.png")
const BG_SNOW:Texture2D = preload("res://assets/snow_stage.png")
const COURIER = {
 "idle":preload("res://assets/courier_idle.png"),
 "walk1":preload("res://assets/courier_walk1.png"),
 "walk2":preload("res://assets/courier_walk2.png"),
 "punch1":preload("res://assets/courier_punch1.png"),
 "kick":preload("res://assets/courier_kick.png"),
 "jump":preload("res://assets/courier_jump.png"),
 "hurt":preload("res://assets/courier_hurt.png"),
 "win":preload("res://assets/courier_win.png"),
 "crouch":preload("res://assets/courier_crouch.png")
}
const CUSTOMER = {
 "idle":preload("res://assets/customer_idle.png"),
 "walk1":preload("res://assets/customer_walk1.png"),
 "walk2":preload("res://assets/customer_walk2.png"),
 "punch1":preload("res://assets/customer_punch1.png"),
 "kick":preload("res://assets/customer_kick.png"),
 "jump":preload("res://assets/customer_jump.png"),
 "hurt":preload("res://assets/customer_hurt.png"),
 "win":preload("res://assets/customer_win.png"),
 "crouch":preload("res://assets/customer_crouch.png")
}
const COWBOY = {
 "idle":preload("res://assets/cowboy_idle.png"),
 "walk1":preload("res://assets/cowboy_walk1.png"),
 "walk2":preload("res://assets/cowboy_walk2.png"),
 "punch1":preload("res://assets/cowboy_punch1.png"),
 "kick":preload("res://assets/cowboy_kick.png"),
 "jump":preload("res://assets/cowboy_jump.png"),
 "hurt":preload("res://assets/cowboy_hurt.png"),
 "win":preload("res://assets/cowboy_win.png"),
 "crouch":preload("res://assets/cowboy_crouch.png"),
 "throw":preload("res://assets/cowboy_throw.png")
}
const SNOWBALL_FRAMES = [
 preload("res://assets/snowball_0.png"),
 preload("res://assets/snowball_1.png"),
 preload("res://assets/snowball_2.png")
]

var stage_id:int = 0    # 0=Terminal, 1=Snögården
var state:String = "title"
var p:Vector2 = Vector2(260,FLOOR)
var e:Vector2 = Vector2(700,FLOOR)
var vy:float = 0.0
var evy:float = 0.0
var hp:float = 100.0
var ehp:float = 100.0
var timer:float = 99.0
var clock:float = 0.0
var cooldown:float = 0.0
var enemy_cooldown:float = 0.0
var attack_time:float = 0.0
var enemy_attack_time:float = 0.0
var player_kick_time:float = 0.0
var enemy_kick_time:float = 0.0
var player_hurt:float = 0.0
var enemy_hurt:float = 0.0
var enemy_throw_time:float = 0.0
var snowball_cooldown:float = 1.2
var freeze:float = 0.0
var special:float = 0.0
var shake:float = 0.0
var round_num:int = 1
var player_score:int = 0
var enemy_score:int = 0
var message:String = ""
var dodge_flash:float = 0.0
var crouch_active:bool = false
var jump_request:bool = false
var flashes:Array = []
var projectiles:Array = []
var snowballs:Array = []
var touches:Dictionary = {}
var touch_origins:Dictionary = {}
var swipe_jumped:Dictionary = {}
var keys:Dictionary = {}

# Four large left thumb buttons and four right thumb actions. 
var buttons:Dictionary = {
 "left":Rect2(16,421,102,104),
 "right":Rect2(124,421,102,104),
 "jump":Rect2(233,433,100,92),
 "crouch":Rect2(341,433,100,92),
 "punch":Rect2(604,416,119,109),
 "kick":Rect2(729,416,119,109),
 "block":Rect2(854,419,90,48),
 "special":Rect2(854,477,90,48)
}
const PLAY:Rect2 = Rect2(343,270,274,64)
const HELP:Rect2 = Rect2(343,352,274,54)
const SELECT_TERMINAL:Rect2 = Rect2(290,243,380,70)
const SELECT_SNOW:Rect2 = Rect2(290,329,380,70)
const SELECT_BACK:Rect2 = Rect2(343,420,274,52)
const HELP_BACK:Rect2 = Rect2(343,451,274,54)
const PAUSE_BUTTON:Rect2 = Rect2(443,108,74,31)
const PAUSE_RESUME:Rect2 = Rect2(346,217,268,55)
const PAUSE_RESTART:Rect2 = Rect2(346,288,268,55)
const PAUSE_HOME:Rect2 = Rect2(346,360,268,55)
const NEXT_ROUND:Rect2 = Rect2(346,285,268,57)
const RESULT_HOME:Rect2 = Rect2(346,359,268,57)

func _ready() -> void:
 texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
 set_process(true)
 set_process_input(true)

func clear_controls() -> void:
 touches.clear()
 touch_origins.clear()
 swipe_jumped.clear()
 keys.clear()
 jump_request = false
 crouch_active = false

func choose_stage(id:int) -> void:
 stage_id = id
 player_score = 0
 enemy_score = 0
 round_num = 1
 next_round()

func menu_tap(at:Vector2) -> void:
 match state:
  "title":
   if PLAY.has_point(at):
    state = "stage_select"
   elif HELP.has_point(at):
    state = "help"
  "stage_select":
   if SELECT_TERMINAL.has_point(at):
    choose_stage(0)
   elif SELECT_SNOW.has_point(at):
    choose_stage(1)
   elif SELECT_BACK.has_point(at):
    state = "title"
  "help":
   if HELP_BACK.has_point(at):
    state = "title"
  "pause":
   if PAUSE_RESUME.has_point(at):
    state = "fight"
   elif PAUSE_RESTART.has_point(at):
    player_score = 0
    enemy_score = 0
    round_num = 1
    next_round()
   elif PAUSE_HOME.has_point(at):
    clear_controls()
    state = "title"
  "round_end", "match_end":
   if NEXT_ROUND.has_point(at):
    next_round()
   elif RESULT_HOME.has_point(at):
    clear_controls()
    state = "title"
 queue_redraw()

func _input(event:InputEvent) -> void:
 if event is InputEventScreenTouch:
  if event.pressed:
   if state != "fight":
    menu_tap(event.position)
    return
   if PAUSE_BUTTON.has_point(event.position):
    clear_controls()
    state = "pause"
    queue_redraw()
    return
   var pressed_button:String = button_at(event.position)
   if pressed_button != "":
    touches[event.index] = pressed_button
    touch_origins[event.index] = event.position
    keys[pressed_button] = true
    if pressed_button == "jump": jump_request = true
  elif touches.has(event.index):
   var old_button:String = touches[event.index]
   touches.erase(event.index)
   touch_origins.erase(event.index)
   swipe_jumped.erase(event.index)
   keys[old_button] = touches.values().has(old_button)
 elif event is InputEventScreenDrag and touches.has(event.index):
  var old_button:String = touches[event.index]
  # The left thumb can swipe up to jump without abandoning movement.
  if (old_button == "left" or old_button == "right") and touch_origins.has(event.index) and not swipe_jumped.has(event.index):
   if event.position.y < touch_origins[event.index].y - 52:
    jump_request = true
    swipe_jumped[event.index] = true
  var new_button:String = button_at(event.position)
  if new_button != "" and new_button != old_button:
   touches[event.index] = new_button
   keys[old_button] = touches.values().has(old_button)
   keys[new_button] = true
   if new_button == "jump": jump_request = true
 elif event is InputEventKey and event.pressed and not event.echo:
  if event.keycode == KEY_ESCAPE or event.keycode == KEY_P:
   if state == "fight":
    clear_controls()
    state = "pause"
   elif state == "pause": state = "fight"
   elif state == "help" or state == "stage_select": state = "title"
  elif event.keycode == KEY_ENTER or event.keycode == KEY_SPACE:
   if state == "title": state = "stage_select"
   elif state == "stage_select": choose_stage(stage_id)
   elif state == "help": state = "title"
   elif state == "pause": state = "fight"
   elif state == "round_end" or state == "match_end": next_round()
  elif state == "stage_select" and event.keycode == KEY_1:
   choose_stage(0)
  elif state == "stage_select" and event.keycode == KEY_2:
   choose_stage(1)
 queue_redraw()

func button_at(at:Vector2) -> String:
 var nearest:float = INF
 var chosen:String = ""
 for name in buttons:
  var rect:Rect2 = buttons[name]
  if rect.grow(11).has_point(at):
   var center:Vector2 = rect.position + rect.size * 0.5
   var dist:float = center.distance_squared_to(at)
   if dist < nearest:
    nearest = dist
    chosen = name
 return chosen

func down(name:String) -> bool:
 var kb:Dictionary = {"left":KEY_A,"right":KEY_D,"jump":KEY_W,"crouch":KEY_S,"punch":KEY_J,"kick":KEY_K,"block":KEY_L,"special":KEY_I}
 return keys.get(name,false) or Input.is_key_pressed(kb[name])

func next_round() -> void:
 if state == "match_end":
  player_score = 0
  enemy_score = 0
  round_num = 1
 clear_controls()
 p = Vector2(260,FLOOR)
 e = Vector2(700,FLOOR)
 vy = 0.0
 evy = 0.0
 hp = 100.0
 ehp = 100.0
 timer = 99.0
 cooldown = 0.0
 enemy_cooldown = 0.7
 attack_time = 0.0
 enemy_attack_time = 0.0
 player_kick_time = 0.0
 enemy_kick_time = 0.0
 player_hurt = 0.0
 enemy_hurt = 0.0
 enemy_throw_time = 0.0
 snowball_cooldown = 1.45
 special = 0.0
 freeze = 0.0
 dodge_flash = 0.0
 projectiles.clear()
 snowballs.clear()
 flashes.clear()
 state = "fight"
 queue_redraw()

func sparks(at:Vector2,tint:Color,amount:int=13) -> void:
 for i in range(amount):
  var angle:float = TAU * float(i) / float(amount)
  flashes.append({"p":at,"v":Vector2(cos(angle),sin(angle))*randf_range(70,225),"life":0.37,"color":tint})

func strike(damage:float,reach:float,duration:float,is_kick:bool=false) -> void:
 cooldown = duration
 attack_time = duration*0.65
 player_kick_time = attack_time if is_kick else 0.0
 if absf(p.x-e.x) < reach and absf(p.y-e.y) < 82:
  ehp = maxf(0.0,ehp-damage)
  enemy_hurt = 0.26
  enemy_throw_time = 0.0
  e.x = clampf(e.x+signf(e.x-p.x)*(30 if is_kick else 22),50,910)
  freeze = 0.07 if is_kick else 0.04
  shake = 0.13
  special = minf(100.0,special+14.0)
  sparks(e+Vector2(0,-108),Color("#ffe282"))
 # A well-timed strike can destroy an incoming snowball too.
 if stage_id == 1:
  for ball in snowballs.duplicate():
   if absf(ball["p"].x-p.x)<reach*0.85 and absf(ball["p"].y-(p.y-104))<78:
    sparks(ball["p"],Color("#d4f8ff"),9)
    snowballs.erase(ball)
    special = minf(100.0,special+4.0)

func enemy_snow_throw() -> void:
 if enemy_hurt>0 or stage_id!=1: return
 var style:float = randf()
 var kind:String = "high" if style < 0.48 else "mid" if style < 0.8 else "low"
 var offset_y:float = -151.0 if kind=="high" else -106.0 if kind=="mid" else -50.0
 var direction:float = signf(p.x-e.x)
 if direction == 0.0: direction = -1.0
 var origin:Vector2 = e+Vector2(direction*81,offset_y)
 snowballs.append({"p":origin,"vx":direction*randf_range(245.0,306.0),"kind":kind,"phase":randf_range(0.0,3.0),"life":4.0})
 enemy_throw_time = 0.36
 sparks(origin,Color("#bce9ff"),5)

func hit_by_snowball(ball:Dictionary) -> void:
 # High and medium throws can be ducked. Low throws can be jumped.
 var is_low:bool = ball["kind"] == "low"
 var avoided:bool = (crouch_active and not is_low) or (is_low and p.y<FLOOR-45)
 if avoided:
  dodge_flash = 0.43
  special = minf(100,special+4)
  sparks(ball["p"],Color("#87ecff"),8)
 elif down("block"):
  dodge_flash = 0.22
  sparks(ball["p"],Color("#90e4ff"),12)
 else:
  hp = maxf(0,hp-(9.0 if is_low else 7.0))
  player_hurt = 0.22
  p.x = clampf(p.x+signf(p.x-e.x)*16.0,50,910)
  shake = 0.14
  freeze = 0.04
  sparks(ball["p"],Color("#fff4fb"),15)

func update_snowballs(delta:float) -> void:
 for ball in snowballs.duplicate():
  ball["p"] += Vector2(ball["vx"]*delta,0)
  ball["life"] -= delta
  var horizontal:float = absf(ball["p"].x-p.x)
  if horizontal<34 and absf(ball["p"].y-p.y)<205:
   hit_by_snowball(ball)
   snowballs.erase(ball)
  elif ball["life"]<=0 or ball["p"].x < -36 or ball["p"].x > 996:
   snowballs.erase(ball)

func _process(delta:float) -> void:
 clock+=delta
 if state != "fight":
  queue_redraw()
  return
 if freeze>0:
  freeze=maxf(0,freeze-delta)
  queue_redraw()
  return
 timer -= delta
 cooldown = maxf(0.0,cooldown-delta)
 enemy_cooldown = maxf(0.0,enemy_cooldown-delta)
 attack_time = maxf(0.0,attack_time-delta)
 enemy_attack_time = maxf(0.0,enemy_attack_time-delta)
 enemy_throw_time = maxf(0.0,enemy_throw_time-delta)
 player_kick_time = maxf(0.0,player_kick_time-delta)
 enemy_kick_time = maxf(0.0,enemy_kick_time-delta)
 player_hurt = maxf(0.0,player_hurt-delta)
 enemy_hurt = maxf(0.0,enemy_hurt-delta)
 shake = maxf(0.0,shake-delta)
 dodge_flash = maxf(0.0,dodge_flash-delta)
 for flash in flashes:
  flash["life"] -= delta
  flash["p"] += flash["v"]*delta
 flashes = flashes.filter(func(a):return a["life"]>0.0)
 crouch_active = down("crouch") and p.y >= FLOOR-2 and player_hurt<=0
 var move_dir:float = float(int(down("right"))-int(down("left")))
 if player_hurt>0 or crouch_active:move_dir=0.0
 p.x = clampf(p.x+move_dir*237.0*delta,48.0,912.0)
 if (jump_request or Input.is_key_pressed(KEY_W)) and p.y>=FLOOR and player_hurt<=0 and not crouch_active:
  vy = -490.0
  jump_request = false
 if crouch_active:jump_request=false
 vy += 1200*delta
 p.y = minf(FLOOR,p.y+vy*delta)
 if p.y>=FLOOR:vy=0.0

 var distance:float = absf(p.x-e.x)
 if enemy_hurt<=0:
  var dir_to_player:float = signf(p.x-e.x)
  var enemy_dir:float = 0.0
  if stage_id==1:
   if distance>335:enemy_dir=dir_to_player
   elif distance<190:enemy_dir=-dir_to_player
  else:
   if distance>125:enemy_dir=dir_to_player
   elif distance<70:enemy_dir=-dir_to_player
  e.x=clampf(e.x+enemy_dir*(124.0 if stage_id==1 else 112.0)*delta,48.0,912.0)
 evy += 1200*delta
 e.y=minf(FLOOR,e.y+evy*delta)
 if e.y>=FLOOR:evy=0.0

 if cooldown<=0 and player_hurt<=0 and not down("block"):
  if down("punch") and not crouch_active:
   strike(9,112,0.33)
  elif down("kick"):
   strike(11 if crouch_active else 15,120 if crouch_active else 145,0.50 if crouch_active else 0.55,true)
  elif down("special") and special>=40:
   special-=40
   projectiles.append({"p":p+Vector2(0,-105),"vx":signf(e.x-p.x)*500.0})
   cooldown=0.60

 if enemy_cooldown<=0 and enemy_hurt<=0 and distance<118 and absf(p.y-e.y)<95:
  enemy_cooldown=randf_range(1.15,1.8) if stage_id==0 else randf_range(1.5,2.1)
  enemy_attack_time=0.32
  enemy_kick_time=0.27 if distance>90 else 0.0
  if crouch_active and enemy_kick_time<=0:
   dodge_flash=0.42
  elif not down("block"):
   hp=maxf(0,hp-(7.0 if stage_id==1 else 8.0))
   player_hurt=0.20
   p.x=clampf(p.x+signf(p.x-e.x)*22,50,910)
   freeze=0.045
   shake=0.13
   sparks(p+Vector2(0,-112),Color("#ff8f85"))

 if stage_id==1:
  snowball_cooldown -= delta
  if snowball_cooldown<=0 and enemy_hurt<=0:
   enemy_snow_throw()
   snowball_cooldown=randf_range(1.45,2.30)
  update_snowballs(delta)

 for shot in projectiles.duplicate():
  shot["p"] += Vector2(shot["vx"]*delta,0)
  if absf(shot["p"].x-e.x)<45 and absf(shot["p"].y-e.y+106)<60:
   ehp = maxf(0.0,ehp-22)
   enemy_hurt=0.25
   enemy_throw_time=0.0
   sparks(e+Vector2(0,-104),Color("#67d9ff"),16)
   projectiles.erase(shot)
  elif shot["p"].x<0 or shot["p"].x>960:
   projectiles.erase(shot)

 if hp<=0 or ehp<=0 or timer<=0:
  if hp>ehp:
   player_score+=1
   message="POSTNORD VINNER!"
  elif ehp>hp:
   enemy_score+=1
   message="COWBOY VINNER!" if stage_id==1 else "KUNDEN VINNER!"
  else:
   message="OAVGJORT!"
  round_num+=1
  state="match_end" if maxi(player_score,enemy_score)>=2 else "round_end"
  clear_controls()
 queue_redraw()

func txt(value:String,at:Vector2,size:int=20,color:Color=Color.WHITE) -> void:
 draw_string(ThemeDB.fallback_font,at,value,HORIZONTAL_ALIGNMENT_LEFT,-1,size,color)

func centered(value:String,y:float,size:int,col:Color=Color.WHITE,area:Rect2=Rect2(0,0,960,540)) -> void:
 var text_width:float = ThemeDB.fallback_font.get_string_size(value,HORIZONTAL_ALIGNMENT_LEFT,-1,size).x
 txt(value,Vector2(area.position.x+(area.size.x-text_width)*0.5,y),size,col)

func menu_button(label:String,r:Rect2,primary:bool=false) -> void:
 draw_rect(r,Color("#031323",0.93))
 draw_rect(r.grow(-3),Color("#f4c659") if primary else Color("#1d3856",0.97))
 draw_rect(r,Color("#ffe090") if primary else Color("#87c9e5"),false,2)
 var text_size:int = 22 if primary else 20
 centered(label,r.position.y+r.size.y*0.5+text_size*0.33,text_size,Color("#1c2b35") if primary else Color("#e1f0ff"),r)

func fighter_art(courier:bool) -> Texture2D:
 var library:Dictionary=COURIER if courier else (COWBOY if stage_id==1 else CUSTOMER)
 var hurt:float=player_hurt if courier else enemy_hurt
 var attack:float=attack_time if courier else enemy_attack_time
 var kick:bool=player_kick_time>0 if courier else enemy_kick_time>0
 var moving:bool=false
 if courier:
  moving=down("left") or down("right")
 elif stage_id==1:
  moving=absf(p.x-e.x)>335
 else:
  moving=absf(p.x-e.x)>125
 var pose:String="idle"
 if hurt>0:
  pose="hurt"
 elif state=="match_end" and ((courier and player_score>enemy_score) or (not courier and enemy_score>player_score)):
  pose="win"
 elif not courier and stage_id==1 and enemy_throw_time>0:
  pose="throw"
 elif attack>0:
  pose="kick" if kick else "punch1"
 elif courier and crouch_active and state=="fight":
  pose="crouch"
 elif (p.y if courier else e.y)<FLOOR-5:
  pose="jump"
 elif moving and state=="fight":
  pose="walk1" if int(clock*9)%2==0 else "walk2"
 return library[pose]

func draw_fighter(at:Vector2,courier:bool) -> void:
 var art:Texture2D = fighter_art(courier)
 var face:bool=e.x>p.x if courier else p.x>e.x
 var scaled:float=0.48
 draw_set_transform(at,0.0,Vector2(1.0 if face else -1.0,1.0))
 draw_texture_rect(art,Rect2(-640.0*scaled/2.0,-570.0*scaled,640.0*scaled,620.0*scaled),false)
 draw_set_transform(Vector2.ZERO)
 if courier and down("block") and state=="fight":
  draw_arc(at+Vector2((40.0 if face else -40.0),-125.0),43,-1.1,1.1,22,Color("#96e9ff",0.86),4)

func draw_shadow(at:Vector2) -> void:
 var vertices:PackedVector2Array=PackedVector2Array()
 for i in range(28):
  var angle:float=TAU*float(i)/28.0
  vertices.append(Vector2(at.x+56*cos(angle),FLOOR+10+8*sin(angle)))
 draw_colored_polygon(vertices,Color("#101b30",0.32))

func snow_effects() -> void:
 # A few drifting snowflakes are deterministic so they don't flicker.
 for i in range(46):
  var seed_x:float=fmod(float(i*143+31),1000.0)
  var seed_y:float=fmod(float(i*97+17),520.0)
  var x:float=fposmod(seed_x+clock*(18.0+float(i%6)*5.0),960.0)
  var y:float=fposmod(seed_y+clock*(35.0+float(i%5)*8.0),540.0)
  draw_circle(Vector2(x,y),1.2+float(i%3)*0.6,Color("#f8fcff",0.32))

func draw_hud() -> void:
 draw_rect(Rect2(0,0,960,103),Color("#08142d",0.97))
 draw_rect(Rect2(0,100,960,4),Color("#e9be61"))
 draw_rect(Rect2(18,33,365,24),Color("#682c40"))
 draw_rect(Rect2(18,33,365*clampf(hp/100.0,0,1),24),Color("#f6cc54"))
 draw_rect(Rect2(577,33,365,24),Color("#682c40"))
 var enemy_ratio:float=clampf(ehp/100.0,0,1)
 draw_rect(Rect2(577+365*(1.0-enemy_ratio),33,365*enemy_ratio,24),Color("#f6cc54"))
 txt("POSTNORD",Vector2(18,25),22,Color("#66d8fc"))
 txt("WOODY" if stage_id==1 else "KUNDEN",Vector2(851 if stage_id==1 else 844,25),22,Color("#ffa38b"))
 centered(str(ceili(timer)),63,42,Color("#ffe0a0"))
 centered("RONDER %d : %d" % [player_score,enemy_score],84,17,Color("#ffffff"))
 draw_rect(Rect2(18,74,190,10),Color("#26324e"))
 draw_rect(Rect2(18,74,190.0*special/100.0,10),Color("#40d1f4"))

func draw_snowball(ball:Dictionary) -> void:
 var sprite:Texture2D=SNOWBALL_FRAMES[int(clock*11+ball["phase"])%3]
 var where:Vector2=ball["p"]
 draw_texture_rect(sprite,Rect2(where.x-23,where.y-23,46,46),false)
 draw_line(where+Vector2(-ball["vx"]*0.07,7),where+Vector2(-ball["vx"]*0.035,3),Color("#b4e8ff",0.5),3)

func draw_controls() -> void:
 for name in buttons:
  var r:Rect2=buttons[name]
  var active:bool=down(name)
  draw_rect(r,Color("#294861",0.78) if not active else Color("#397b9c",0.92))
  draw_rect(r,Color("#aed9ee",0.92),false,2)
  var caption:String={"left":"<","right":">","jump":"HOPP","crouch":"HUKA","punch":"SLAG","kick":"SPARK","block":"SKYDD","special":"SUPER"}[name]
  var size:int=20 if name=="left" or name=="right" else 16
  centered(caption,r.position.y+r.size.y*0.5+size*0.33,size,Color("#f3f7ff"),r)
 draw_rect(PAUSE_BUTTON,Color("#14293c",0.83))
 draw_rect(PAUSE_BUTTON,Color("#81bdd7"),false,1)
 centered("PAUS",PAUSE_BUTTON.position.y+21,14,Color("#d6eeff"),PAUSE_BUTTON)
 if timer>93:
  txt("SVEP UPP FOR HOPP",Vector2(22,407),12,Color("#e3f6ff",0.84))
 if dodge_flash>0:
  txt("DUCK!",Vector2(p.x-26,p.y-186),21,Color("#8befff"))

func draw_menu_backdrop() -> void:
 var backdrop:Texture2D=BG_TERMINAL if stage_id==0 else BG_SNOW
 draw_texture_rect(backdrop,Rect2(0,0,960,540),false)
 draw_rect(Rect2(0,0,960,540),Color("#061329",0.58))
 draw_fighter(Vector2(168,470),true)
 draw_fighter(Vector2(805,470),false)
 draw_rect(Rect2(265,0,430,540),Color("#09162b",0.90))
 draw_rect(Rect2(264,0,3,540),Color("#efc563",0.8))
 draw_rect(Rect2(694,0,3,540),Color("#efc563",0.8))

func draw_title_screen() -> void:
 draw_menu_backdrop()
 centered("PAKETKRIGET",128,54,Color("#f5c75d"))
 centered("TERMINAL CLASH",173,28,Color("#74dafa"))
 centered("TVÅ BANOR  ·  TVÅ MOTSTÅNDARE",213,17,Color("#d2e7f4"))
 menu_button("STARTA SPEL",PLAY,true)
 menu_button("SÅ SPELAR DU",HELP)
 centered("SNÖBOLLAR  ·  SLAG  ·  SPARKAR",485,15,Color("#ddebf8"))

func draw_stage_select() -> void:
 draw_menu_backdrop()
 centered("VÄLJ BANA",153,44,Color("#f5c75d"))
 centered("VÄLJ DIN NÄSTA STRID",201,19,Color("#b8dfea"))
 menu_button("1  ·  TERMINALEN",SELECT_TERMINAL,true)
 menu_button("2  ·  SNÖGÅRDEN",SELECT_SNOW,true)
 menu_button("TILLBAKA",SELECT_BACK)

func draw_help_screen() -> void:
 draw_rect(Rect2(0,0,960,540),Color("#081729",0.91))
 draw_rect(Rect2(100,54,760,475),Color("#0b203a",0.98))
 draw_rect(Rect2(100,54,760,475),Color("#f0c46e"),false,3)
 centered("SÅ SPELAR DU",116,37,Color("#f6d06f"))
 txt("VÄNSTER / HÖGER: FÖRFLYTTA DIG",Vector2(149,162),20)
 txt("HOPP: KNAPP ELLER SVEP UPP",Vector2(149,204),20)
 txt("HUKA: HÅLL INNE FÖR ATT DUCKA",Vector2(149,246),20)
 txt("SLAG / SPARK: ANFALL",Vector2(149,288),20)
 txt("SKYDD: BLOCKERA · SUPER: LADDAD ATTACK",Vector2(149,330),18)
 txt("SNÖGÅRDEN: DUCKA FÖR HÖGA SNÖBOLLAR",Vector2(149,385),18,Color("#8fdefb"))
 txt("HOPPA ÖVER DE LÅGA!",Vector2(149,413),18,Color("#8fdefb"))
 menu_button("TILLBAKA",HELP_BACK)

func draw_pause_screen() -> void:
 draw_rect(Rect2(0,0,960,540),Color("#06101d",0.76))
 draw_rect(Rect2(272,135,416,322),Color("#071a30",0.98))
 draw_rect(Rect2(272,135,416,322),Color("#f0c56b"),false,3)
 centered("PAUS",191,41,Color("#f8d173"))
 menu_button("FORTSÄTT",PAUSE_RESUME,true)
 menu_button("BÖRJA OM",PAUSE_RESTART)
 menu_button("HUVUDMENY",PAUSE_HOME)

func draw_result_screen() -> void:
 draw_rect(Rect2(0,0,960,540),Color("#071325",0.63))
 draw_rect(Rect2(270,148,420,300),Color("#0a1c31",0.98))
 draw_rect(Rect2(270,148,420,300),Color("#edc56e"),false,3)
 centered(message,227,27,Color("#f6cf71"))
 menu_button("SPELA IGEN" if state=="match_end" else "NÄSTA ROND",NEXT_ROUND,true)
 menu_button("HUVUDMENY",RESULT_HOME)

func _draw() -> void:
 if state=="title":
  draw_title_screen()
  return
 if state=="stage_select":
  draw_stage_select()
  return
 if state=="help":
  draw_help_screen()
  return
 draw_texture_rect(BG_TERMINAL if stage_id==0 else BG_SNOW,Rect2(0,0,960,540),false)
 if stage_id==1: snow_effects()
 for fighter_position in [p,e]:draw_shadow(fighter_position)
 if shake>0:
  draw_set_transform(Vector2(randf_range(-2,2),randf_range(-2,2)))
 draw_fighter(p,true)
 draw_fighter(e,false)
 draw_set_transform(Vector2.ZERO)
 for ball in snowballs: draw_snowball(ball)
 for shot in projectiles:
  draw_rect(Rect2(shot["p"].x-14,shot["p"].y-14,28,28),Color("#c69b65"))
  draw_rect(Rect2(shot["p"].x-4,shot["p"].y-14,8,28),Color("#76502f"))
 for flash in flashes:
  draw_circle(flash["p"],maxf(1.0,5.0*flash["life"]/0.37),flash["color"])
 draw_hud()
 if state=="fight":draw_controls()
 if state=="pause":draw_pause_screen()
 if state=="round_end" or state=="match_end":draw_result_screen()
